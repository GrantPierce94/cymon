package com.experiments.webApp_mvn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebAppMvnApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebAppMvnApplication.class, args);
	}

}
