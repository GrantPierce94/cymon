package com.experiments.webApp_mvn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebAppMvnApplicationTests {

	@Test
	void contextLoads() {
	}

}
