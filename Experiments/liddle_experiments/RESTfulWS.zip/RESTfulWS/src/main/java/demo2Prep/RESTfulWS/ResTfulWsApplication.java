package demo2Prep.RESTfulWS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResTfulWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResTfulWsApplication.class, args);
	}

}
