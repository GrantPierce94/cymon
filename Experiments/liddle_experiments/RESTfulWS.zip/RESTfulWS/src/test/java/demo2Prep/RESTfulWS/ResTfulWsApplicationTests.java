package demo2Prep.RESTfulWS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResTfulWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
