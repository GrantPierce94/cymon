package com.genuinecoder.SpringServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
