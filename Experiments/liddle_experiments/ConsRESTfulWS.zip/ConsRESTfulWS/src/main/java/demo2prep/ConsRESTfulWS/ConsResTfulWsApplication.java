package demo2prep.ConsRESTfulWS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsResTfulWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsResTfulWsApplication.class, args);
	}

}
