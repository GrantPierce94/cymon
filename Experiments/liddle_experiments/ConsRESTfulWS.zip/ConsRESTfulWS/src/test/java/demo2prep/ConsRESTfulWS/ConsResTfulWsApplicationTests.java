package demo2prep.ConsRESTfulWS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsResTfulWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
